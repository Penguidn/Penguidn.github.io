<!DOCTYPE html>
<html>
<body>    

<h1>Login</h1>
<form action="logintarget.php" method="POST">
    <label for="user">Username:</label><br>
    <input type="text" id="user" name="user"><br>
    <label for="pass">Password:</label><br>
    <input type="text" id="pass" name="pass">
    <input type="submit" value="Submit">
</form>

</body>
</html>
