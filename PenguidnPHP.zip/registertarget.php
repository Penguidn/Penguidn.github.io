<!DOCTYPE html>
<html  lang="en">
	<head>

	</head>

	<body>
	
	<?php
		$username = $_POST["user"];
		$password = $_POST["pass"];
		$fullname = $_POST["fullname"];
		$email = $_POST["email"];
		$address = $_POST["address"];
	?>

	<h2>Form Target Page</h2>
	
	<p>Welcome <?php echo $username; ?></p>
	<p>Welcome <?php echo $password; ?></p>
	<p>Welcome <?php echo $fullname; ?></p>
	<p>Welcome <?php echo $email; ?></p>
	<p>Welcome <?php echo $address; ?></p>

	</body>
</html>
