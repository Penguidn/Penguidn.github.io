<!DOCTYPE html>
<html>
<body>

<h1>Register</h1>
<form action="registertarget.php" method="POST">
    <label for="user">Username:</label><br>
    <input type="text" id="user" name="user"><br>
    <label for="pass">Password:</label><br>
    <input type="text" id="pass" name="pass"><br>
    <label for="fullname">First and last name:</label><br>
    <input type="text" id="fullname" name="fullname"><br>
    <label for="email">Email:</label><br>
    <input type="text" id="email" name="email"><br>
    <label for="address">Address:</label><br>
    <input type="text" id="address" name="address"><br>
    <input type="submit" value="Submit">
</form>

</body>
</html>
