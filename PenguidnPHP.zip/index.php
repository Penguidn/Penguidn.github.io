<!DOCTYPE html>
<html>
<head>
<title>Ecommerce Website</title>
<link rel="stylesheet" href="External.css">
</head>
<body>

<h1>Index/Home</h1>
<p></p>

<?php include "nav.php";
?>
    
</body>
</html>
