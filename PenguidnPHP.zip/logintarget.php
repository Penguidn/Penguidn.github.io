<!DOCTYPE html>
<html  lang="en">

	<body>

	<?php
		$username = $_POST["user"];
		$password = $_POST["pass"];
	?>

	<h2>Form Target Page</h2>
	
	<p>Welcome <?php echo $username; ?></p>
	<p>Your password is: <?php echo $password; ?> </p>

	</body>
</html>
