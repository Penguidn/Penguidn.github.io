<?php
	echo '<ul> -
		<li><a href="index.php">Home</a></li> -
		<li><a href="login.php">Login</a></li> -
		<li><a href="catalog.php">Catalog</a></li> -
		<li><a href="about.php">About</a></li> -
	</ul>';
?>